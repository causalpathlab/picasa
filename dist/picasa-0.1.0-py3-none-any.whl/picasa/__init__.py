from .picasa import create_picasa_object
